// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FtlDef.java

package codeGenerate.def;


public final class FtlDef
{

	public static String FIELD_REQUIRED_NAME = "field_required_num";
	public static String FIELD_ROW_NAME = "field_row_num";
	public static String CG_TABLE_ID = "cg_table_id";
	public static String SEARCH_FIELD_NUM = "search_field_num";
	public static String KEY_TYPE_01 = "01";
	public static String KEY_TYPE_02 = "02";

	private FtlDef()
	{
	}

}
